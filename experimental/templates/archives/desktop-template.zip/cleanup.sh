#!/bin/sh
rm -rf .idea
./gradlew clean
rm -rf .gradle
rm -rf build
