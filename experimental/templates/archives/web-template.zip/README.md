# Compose Web Application

You may download this template as a [zip file](../archives/web-template.zip). 

- `./gradlew jsBrowserRun` - run application in a browser
- `./gradlew jsBrowserProductionWebpack` - produce the output in `build/distributions`